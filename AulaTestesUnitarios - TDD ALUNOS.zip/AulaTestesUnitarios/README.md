# AulaTestesUnitarios
Repositório com código exemplo para aula de Testes Unitários

Novo requisito: Além da bonificação já existente, foi solicitado à equipe de desenvolvimento a criação de uma nova feature de bonificação baseado em escalas de anos de serviço na empresa e outro por cargo ocupado. 

 - Para cada 5 anos de serviço à empresa, 5% de adicional deverá ser oferecido ao colaborador até um máximo de 20%;
 - Caso o caloborador receba uma promoção, o salário deverá ser aumentado em 20%;
